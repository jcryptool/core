package de.flexiprovider.common.math.quadraticfields;

public class IQEncodingException extends Exception {

    public IQEncodingException(String msg) {
	super(msg);
    }

}
