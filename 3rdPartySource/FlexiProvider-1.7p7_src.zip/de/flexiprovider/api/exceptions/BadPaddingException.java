package de.flexiprovider.api.exceptions;

public class BadPaddingException extends javax.crypto.BadPaddingException {

    public BadPaddingException() {
	super();
    }

    public BadPaddingException(String msg) {
	super(msg);
    }

}
