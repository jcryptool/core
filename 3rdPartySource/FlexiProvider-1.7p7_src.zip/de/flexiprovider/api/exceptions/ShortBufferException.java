package de.flexiprovider.api.exceptions;

public class ShortBufferException extends javax.crypto.ShortBufferException {

    public ShortBufferException() {
	super();
    }

    public ShortBufferException(String msg) {
	super(msg);
    }

}
