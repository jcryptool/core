package de.flexiprovider.api.exceptions;

public class NoSuchPaddingException extends javax.crypto.NoSuchPaddingException {

    public NoSuchPaddingException(String msg) {
	super(msg);
    }

}
