package de.flexiprovider.api.exceptions;

public class InvalidKeySpecException extends
	java.security.spec.InvalidKeySpecException {

    public InvalidKeySpecException() {
	super();
    }

    public InvalidKeySpecException(String msg) {
	super(msg);
    }

}
