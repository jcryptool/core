package de.flexiprovider.api.exceptions;

public class NoSuchAlgorithmException extends
	java.security.NoSuchAlgorithmException {

    public NoSuchAlgorithmException(String msg) {
	super(msg);
    }

}
