package de.flexiprovider.api.keys;

public interface Key extends java.security.Key {

    // empty

}
