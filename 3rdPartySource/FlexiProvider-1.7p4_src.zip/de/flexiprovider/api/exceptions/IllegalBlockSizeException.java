package de.flexiprovider.api.exceptions;

public class IllegalBlockSizeException extends
	javax.crypto.IllegalBlockSizeException {

    public IllegalBlockSizeException(String msg) {
	super(msg);
    }

}
