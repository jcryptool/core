package de.flexiprovider.api.exceptions;

public class InvalidKeyException extends java.security.InvalidKeyException {

    public InvalidKeyException() {
	super();
    }

    public InvalidKeyException(String msg) {
	super(msg);
    }

}
