/*
 * Created on Mar 25, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package de.flexiprovider.common.exceptions;

public class NotYetImplementedException extends RuntimeException {

    public NotYetImplementedException() {
	// empty
    }

    public NotYetImplementedException(String message) {
	super(message);
    }

}
