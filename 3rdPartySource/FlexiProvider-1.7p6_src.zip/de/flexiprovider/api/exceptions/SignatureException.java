package de.flexiprovider.api.exceptions;

public class SignatureException extends java.security.SignatureException {

    public SignatureException(String msg) {
	super(msg);
    }

}
