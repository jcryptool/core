package de.flexiprovider.api.exceptions;

public class InvalidParameterSpecException extends
	java.security.spec.InvalidParameterSpecException {

    public InvalidParameterSpecException(String msg) {
	super(msg);
    }

}
