package de.flexiprovider.api.exceptions;

public class DigestException extends java.security.DigestException {

    public DigestException(String msg) {
	super(msg);
    }

}
