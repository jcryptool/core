package de.flexiprovider.api.keys;

public interface SecretKey extends Key, javax.crypto.SecretKey {

    // empty

}
